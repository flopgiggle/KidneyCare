﻿/**************************************************************************************************
 * Author:      ChenJing
 * FileName:    UserDto
 * FrameWork:   4.5.2
 * CreateDate:  2015/11/24 15:25:06
 * Description:  User显示实体
 * 
 * ************************************************************************************************/

using System;

namespace KidneyCareApi.Dto
{
    /// <summary>
    /// User显示实体
    /// </summary>
    public class UserDto
    {
        private string userTypeShow;
        /// <summary>
        /// 用户类型显示
        /// </summary>
        public string UserTypeShow
        {
            get { return userTypeShow; }
            set
            {

                userTypeShow = value;
            }
        }

        public int Id { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string ShowName { get; set; }
        public int? UserType { get; set; }
        public DateTime? CreateTime { get; set; }
        public string MobiePhone { get; set; }

        public string Token { get; set; }
        public bool? IsDelete { get; set; }
    }

    /// <summary>
    /// User显示实体
    /// </summary>
    public class UserLoginDto
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
    /// <summary>
    /// 用户注册
    /// </summary>
    public class UserRegistDto
    {
        //public string UserName { get; set; }
        //public string Password { get; set; }
        //public int? UserType { get; set; }
        //public string MobiePhone { get; set; }
        //public bool? IsDelete { get; set; }
        //public string AuthenCode { get; set; }


        public string UserName { get; set; }
        public string MobilePhone { get; set; }
        public string Birthday { get; set; }
        public int BelongToHospital { get; set; }
        public string Sex { get; set; }
        public int UserType { get; set; }
        public int BelongToNurse { get; set; }
        public int BelongToDoctor { get; set; }
        public string OpenId { get; set; }
    }

    /// <summary>
    /// 重置密码
    /// </summary>
    public class ResetPasswordDto
    {
        public string Password { get; set; }
        public int? UserType { get; set; }
        public string MobiePhone { get; set; }
        public string AuthenCode { get; set; }
    }

    /// <summary>
    /// 验证码相关
    /// </summary>
    public class AuthenCodeInfoDto
    {
        /// <summary>
        /// 电话号码
        /// </summary>
        public string PhoneNumber { get; set; }
        /// <summary>
        /// 验证码
        /// </summary>
        public string AuthenCode { get; set; }
        /// <summary>
        /// 验证码输入错误次数
        /// </summary>
        public int CodeErrorTimes { get; set; }
        /// <summary>
        /// 获取验证码次数
        /// </summary>
        public int GetCodeTimes { get; set; }
    }

}
